<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Krishna Pal — Web Developer</title>

  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet" />
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700;900&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet" />
  <!-- Custom CSS -->
    <link rel="icon" href="favicon_icons/favicon.ico" sizes="any">

<link rel="icon" type="image/png" sizes="32x32" href="favicon_icons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="favicon_icons/favicon-16x16.png">

<link rel="apple-touch-icon" sizes="180x180" href="favicon_icons/apple-touch-icon.png">

<link rel="icon" type="image/png" sizes="192x192" href="favicon_icons/android-chrome-192x192.png">
<link rel="icon" type="image/png" sizes="512x512" href="favicon_icons/android-chrome-512x512.png">
    
  <link rel="stylesheet" href="style.css" />
</head>
<body>

  <!-- ============================================================
       NAVBAR
  ============================================================ -->
  <nav id="mainNav" class="navbar navbar-expand-lg fixed-top">
    <div class="container">
      <!-- Brand / Logo -->
      <a class="navbar-brand" href="#home">
        <span class="brand-dot"></span>KP<span class="brand-period">.</span>
      </a>

      <!-- Mobile Toggle -->
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
              data-bs-target="#navbarNav" aria-controls="navbarNav"
              aria-expanded="false" aria-label="Toggle navigation">
        <span class="toggler-icon"><span></span><span></span><span></span></span>
      </button>

      <!-- Nav Links -->
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-2">
          <li class="nav-item"><a class="nav-link" href="#home">Home</a></li>
          <li class="nav-item"><a class="nav-link" href="#about">About</a></li>
          <li class="nav-item"><a class="nav-link" href="#skills">Skills</a></li>
          <li class="nav-item"><a class="nav-link" href="#projects">Projects</a></li>
          <li class="nav-item"><a class="nav-link" href="#resume">Resume</a></li>
          <li class="nav-item ms-lg-3">
            <a class="nav-link nav-cta" href="#contact">Contact</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>


  <!-- ============================================================
       HERO / HOME SECTION
  ============================================================ -->
  <section id="home" class="hero-section d-flex align-items-center">
    <!-- Decorative background elements -->
    <div class="hero-blob hero-blob-1"></div>
    <div class="hero-blob hero-blob-2"></div>
    <div class="hero-grid"></div>

    <div class="container">
      <div class="row align-items-center g-5">

        <!-- Text Content -->
        <div class="col-lg-7 hero-text" data-aos="fade-right">
          <p class="hero-eyebrow">
            <span class="eyebrow-line"></span> Hello
          </p>
          <h1 class="hero-name">
            I'm <span class="highlight">Krishna Pal</span>
          </h1>
          <h2 class="hero-title">Web Developer<span class="cursor-blink">|</span></h2>
          <p class="hero-desc">
            I am a dedicated web developer focused on building modern, scalable, and responsive web applications using PHP and modern frameworks. Turning ideas into efficient digital solutions through clean and reliable code.
          </p>
          <div class="hero-buttons d-flex flex-wrap gap-3">
            <a href="#projects" class="btn btn-primary-custom">
              <i class="bi bi-grid-1x2-fill me-2"></i>View Projects
            </a>
            <a href="#contact" class="btn btn-outline-custom">
              <i class="bi bi-send-fill me-2"></i>Hire Me
            </a>
          </div>
          <!-- Quick stats -->
          <div class="hero-stats d-flex flex-wrap gap-4 mt-5">
            <div class="stat-item">
              <span class="stat-num">3+</span>
              <span class="stat-label">Years Coding</span>
            </div>
            <div class="stat-divider"></div>
            <div class="stat-item">
              <span class="stat-num">20+</span>
              <span class="stat-label">Projects Done</span>
            </div>
            <div class="stat-divider"></div>
            <div class="stat-item">
              <span class="stat-num">10+</span>
              <span class="stat-label">Happy Clients</span>
            </div>
          </div>
        </div>

        <!-- Profile Image -->
        <div class="col-lg-5 text-center" data-aos="fade-left">
          <div class="profile-frame">
            <div class="profile-ring"></div>
            <div class="profile-img-wrap">
              <!-- Replace src with your own photo -->
              <img src="https://placehold.co/380x380/1a1a2e/e8c547?text=KP&font=playfair-display"
                   alt="Krishna Pal" class="profile-img" />
            </div>
            <!-- Floating badges -->
            <!-- <div class="floating-badge badge-1">
              <i class="bi bi-code-slash"></i> Open to Work
            </div>
            <div class="floating-badge badge-2">
              <i class="bi bi-star-fill"></i> 5.0 Rating
            </div> -->
          </div>
        </div>

      </div>
    </div>

    <!-- Scroll Indicator -->
    <a href="#about" class="scroll-indicator">
      <span>Scroll</span>
      <i class="bi bi-arrow-down-circle"></i>
    </a>
  </section>


  <!-- ============================================================
       ABOUT SECTION
  ============================================================ -->
  <section id="about" class="section-pad">
    <div class="container">

      <div class="section-header text-center mb-5">
        <p class="section-label">Get To Know Me</p>
        <h2 class="section-title">About <span class="highlight">Me</span></h2>
      </div>

      <div class="row align-items-center g-5">

        <!-- Image Column -->
        <div class="col-lg-5" data-aos="fade-right">
          <div class="about-img-wrap">
            <img src="https://placehold.co/480x560/0f3460/e8c547?text=About+Me&font=playfair-display"
                 alt="About Me" class="about-img" />
            <div class="about-badge">
              <i class="bi bi-laptop"></i>
              <div>
                <strong>Full-Stack</strong>
                <small>Developer</small>
              </div>
            </div>
            <div class="about-exp-card">
              <span class="exp-num">3+</span>
              <span class="exp-text">Years of<br/>Experience</span>
            </div>
          </div>
        </div>

        <!-- Text Column -->
        <div class="col-lg-7" data-aos="fade-left">
          <h3 class="about-greeting">
            Building Modern Web Applications with Clean Code & Smart Solutions
          </h3>

          <p class="about-text">
            I am a web developer who enjoys transforming ideas into functional and user-friendly web applications.
            I focus on creating responsive, efficient, and scalable websites using modern technologies and frameworks.
            From simple landing pages to dynamic web platforms, I strive to deliver clean and reliable solutions.
          </p>

          <p class="about-text">
            I continuously learn new technologies and improve my development skills to stay aligned with modern web
            standards. My work involves both frontend and backend development, ensuring smooth performance and
            a great user experience. I enjoy solving problems through code and building systems that are practical
            and efficient.
          </p>

          <!-- Info grid -->
          <div class="about-info-grid">
            <div class="info-item">
              <i class="bi bi-person-circle"></i>
              <div>
                <span class="info-label">Name</span>
                <span class="info-val">Krishna Pal</span>
              </div>
            </div>
            <div class="info-item">
              <i class="bi bi-envelope-fill"></i>
              <div>
                <span class="info-label">Email</span>
                <span class="info-val">krishna66dev@gmail.com</span>
              </div>
            </div>
            <div class="info-item">
              <i class="bi bi-geo-alt-fill"></i>
              <div>
                <span class="info-label">Location</span>
                <span class="info-val">Naharpur Rohini sector-7 Delhi-110085</span>
              </div>
            </div>
            <div class="info-item">
              <i class="bi bi-briefcase-fill"></i>
              <div>
                <span class="info-label">Availability</span>
                <span class="info-val available">Available for Work</span>
              </div>
            </div>
          </div>

          <a href="#contact" class="btn btn-primary-custom mt-4">
            <i class="bi bi-chat-dots-fill me-2"></i>Let's Talk
          </a>
        </div>

      </div>
    </div>
  </section>


  <!-- ============================================================
       SKILLS SECTION
  ============================================================ -->
  <section id="skills" class="section-pad skills-section">
    <div class="container">

      <div class="section-header text-center mb-5">
        <p class="section-label">What I Know</p>
        <h2 class="section-title">My <span class="highlight">Skills</span></h2>
      </div>

      <!-- Skill Cards Row -->
      <div class="row g-4 mb-5">

        <!-- PHP -->
        <div class="col-sm-6 col-lg-4" data-aos="fade-up" data-aos-delay="160">
          <div class="skill-card">
            <div class="skill-icon" style="--clr:#777bb4;">
              <i class="bi bi-filetype-php"></i>
            </div>
            <h5 class="skill-name">PHP</h5>
            <p class="skill-desc">Core PHP development, REST APIs, authentication systems, and backend logic.</p>
            <div class="skill-bar-wrap">
              <div class="skill-bar-track">
                <div class="skill-bar-fill" data-pct="90" style="--clr:#777bb4;"></div>
              </div>
              <span class="skill-pct">90%</span>
            </div>
          </div>
        </div>

        <!-- MySQL -->
        <div class="col-sm-6 col-lg-4" data-aos="fade-up" data-aos-delay="180">
          <div class="skill-card">
            <div class="skill-icon" style="--clr:#00758f;">
              <i class="bi bi-database"></i>
            </div>
            <h5 class="skill-name">MySQL</h5>
            <p class="skill-desc">Database design, complex queries, indexing, optimization, and relational data management.</p>
            <div class="skill-bar-wrap">
              <div class="skill-bar-track">
                <div class="skill-bar-fill" data-pct="88" style="--clr:#00758f;"></div>
              </div>
              <span class="skill-pct">88%</span>
            </div>
          </div>
        </div>

        <!-- CodeIgniter -->
        <div class="col-sm-6 col-lg-4" data-aos="fade-up" data-aos-delay="200">
          <div class="skill-card">
            <div class="skill-icon" style="--clr:#ee4323;">
              <i class="bi bi-code-slash"></i>
            </div>
            <h5 class="skill-name">CodeIgniter</h5>
            <p class="skill-desc">MVC architecture, REST APIs, authentication systems, and scalable web applications.</p>
            <div class="skill-bar-wrap">
              <div class="skill-bar-track">
                <div class="skill-bar-fill" data-pct="85" style="--clr:#ee4323;"></div>
              </div>
              <span class="skill-pct">85%</span>
            </div>
          </div>
        </div>

        <!-- Laravel -->
        <div class="col-sm-6 col-lg-4" data-aos="fade-up" data-aos-delay="220">
          <div class="skill-card">
            <div class="skill-icon" style="--clr:#ff2d20;">
              <i class="bi bi-layers"></i>
            </div>
            <h5 class="skill-name">Laravel</h5>
            <p class="skill-desc">Modern PHP framework with MVC, REST APIs, authentication, queues, and scalable apps.</p>
            <div class="skill-bar-wrap">
              <div class="skill-bar-track">
                <div class="skill-bar-fill" data-pct="87" style="--clr:#ff2d20;"></div>
              </div>
              <span class="skill-pct">87%</span>
            </div>
          </div>
        </div>
        <!-- HTML -->
        <div class="col-sm-6 col-lg-4" data-aos="fade-up" data-aos-delay="0">
          <div class="skill-card">
            <div class="skill-icon" style="--clr:#e34f26;">
              <i class="bi bi-filetype-html"></i>
            </div>
            <h5 class="skill-name">HTML</h5>
            <p class="skill-desc">Semantic markup, accessibility, and structured document architecture.</p>
            <div class="skill-bar-wrap">
              <div class="skill-bar-track">
                <div class="skill-bar-fill" data-pct="92" style="--clr:#e34f26;"></div>
              </div>
              <span class="skill-pct">92%</span>
            </div>
          </div>
        </div>

        <!-- CSS -->
        <div class="col-sm-6 col-lg-4" data-aos="fade-up" data-aos-delay="80">
          <div class="skill-card">
            <div class="skill-icon" style="--clr:#264de4;">
              <i class="bi bi-filetype-css"></i>
            </div>
            <h5 class="skill-name">CSS</h5>
            <p class="skill-desc">Flexbox, Grid, animations, custom properties, and responsive design.</p>
            <div class="skill-bar-wrap">
              <div class="skill-bar-track">
                <div class="skill-bar-fill" data-pct="88" style="--clr:#264de4;"></div>
              </div>
              <span class="skill-pct">88%</span>
            </div>
          </div>
        </div>

        <!-- JavaScript -->
        <div class="col-sm-6 col-lg-4" data-aos="fade-up" data-aos-delay="160">
          <div class="skill-card">
            <div class="skill-icon" style="--clr:#f7df1e;">
              <i class="bi bi-filetype-js"></i>
            </div>
            <h5 class="skill-name">JavaScript</h5>
            <p class="skill-desc">ES6+, DOM manipulation, async/await, APIs, and modern JS patterns.</p>
            <div class="skill-bar-wrap">
              <div class="skill-bar-track">
                <div class="skill-bar-fill" data-pct="85" style="--clr:#f7df1e;"></div>
              </div>
              <span class="skill-pct">85%</span>
            </div>
          </div>
        </div>

        <!-- Bootstrap -->
        <div class="col-sm-6 col-lg-4" data-aos="fade-up" data-aos-delay="0">
          <div class="skill-card">
            <div class="skill-icon" style="--clr:#7952b3;">
              <i class="bi bi-bootstrap-fill"></i>
            </div>
            <h5 class="skill-name">Bootstrap</h5>
            <p class="skill-desc">Rapid prototyping, grid system, components, and utility classes.</p>
            <div class="skill-bar-wrap">
              <div class="skill-bar-track">
                <div class="skill-bar-fill" data-pct="90" style="--clr:#7952b3;"></div>
              </div>
              <span class="skill-pct">90%</span>
            </div>
          </div>
        </div>

        <!-- Git & GitHub -->
        <div class="col-sm-6 col-lg-4" data-aos="fade-up" data-aos-delay="80">
          <div class="skill-card">
            <div class="skill-icon" style="--clr:#f05032;">
              <i class="bi bi-git"></i>
            </div>
            <h5 class="skill-name">Git &amp; GitHub</h5>
            <p class="skill-desc">Version control, branching, pull requests, and collaborative workflows.</p>
            <div class="skill-bar-wrap">
              <div class="skill-bar-track">
                <div class="skill-bar-fill" data-pct="82" style="--clr:#f05032;"></div>
              </div>
              <span class="skill-pct">82%</span>
            </div>
          </div>
        </div>

        <!-- Responsive Design -->
        <div class="col-sm-6 col-lg-4" data-aos="fade-up" data-aos-delay="160">
          <div class="skill-card">
            <div class="skill-icon" style="--clr:#00bcd4;">
              <i class="bi bi-phone-fill"></i>
            </div>
            <h5 class="skill-name">Responsive Design</h5>
            <p class="skill-desc">Mobile-first approach, media queries, fluid layouts, and cross-browser support.</p>
            <div class="skill-bar-wrap">
              <div class="skill-bar-track">
                <div class="skill-bar-fill" data-pct="94" style="--clr:#00bcd4;"></div>
              </div>
              <span class="skill-pct">94%</span>
            </div>
          </div>
        </div>

      </div><!-- /row -->
    </div>
  </section>


  <!-- ============================================================
       PROJECTS SECTION
  ============================================================ -->
  <section id="projects" class="section-pad d-none">
    <div class="container">

      <div class="section-header text-center mb-5">
        <p class="section-label">What I've Built</p>
        <h2 class="section-title">My <span class="highlight">Projects</span></h2>
      </div>

      <!-- Filter Tabs -->
      <div class="project-filters text-center mb-5">
        <button class="filter-btn active" data-filter="all">All</button>
        <button class="filter-btn" data-filter="frontend">Frontend</button>
        <button class="filter-btn" data-filter="fullstack">Full Stack</button>
      </div>

      <div class="row g-4" id="projectsGrid">

        <!-- Project 1: Portfolio Website -->
        <div class="col-md-6 col-lg-4 project-item frontend" data-aos="fade-up" data-aos-delay="0">
          <div class="project-card">
            <div class="project-img-wrap">
              <img src="https://placehold.co/560x340/1a1a2e/e8c547?text=Portfolio&font=playfair-display"
                   alt="Portfolio Website" class="project-img" />
              <div class="project-overlay">
                <a href="#" class="overlay-btn" target="_blank">
                  <i class="bi bi-eye-fill"></i>
                </a>
                <a href="#" class="overlay-btn" target="_blank">
                  <i class="bi bi-github"></i>
                </a>
              </div>
            </div>
            <div class="project-body">
              <div class="project-tags">
                <span class="tag">HTML</span>
                <span class="tag">CSS</span>
                <span class="tag">JavaScript</span>
                <span class="tag">Bootstrap</span>
              </div>
              <h5 class="project-title">Portfolio Website</h5>
              <p class="project-desc">
                A fully responsive personal portfolio website to showcase projects, skills,
                and experience — built with modern design principles.
              </p>
              <div class="project-links">
                <a href="#" class="btn btn-sm btn-primary-custom" target="_blank">
                  <i class="bi bi-play-fill me-1"></i>Live Demo
                </a>
                <a href="#" class="btn btn-sm btn-ghost" target="_blank">
                  <i class="bi bi-github me-1"></i>GitHub
                </a>
              </div>
            </div>
          </div>
        </div>

        <!-- Project 2: To-Do List App -->
        <div class="col-md-6 col-lg-4 project-item fullstack" data-aos="fade-up" data-aos-delay="100">
          <div class="project-card">
            <div class="project-img-wrap">
              <img src="https://placehold.co/560x340/0f3460/e8c547?text=To-Do+App&font=playfair-display"
                   alt="To-Do List App" class="project-img" />
              <div class="project-overlay">
                <a href="#" class="overlay-btn" target="_blank">
                  <i class="bi bi-eye-fill"></i>
                </a>
                <a href="#" class="overlay-btn" target="_blank">
                  <i class="bi bi-github"></i>
                </a>
              </div>
            </div>
            <div class="project-body">
              <div class="project-tags">
                <span class="tag">JavaScript</span>
                <span class="tag">LocalStorage</span>
                <span class="tag">CSS</span>
              </div>
              <h5 class="project-title">To-Do List App</h5>
              <p class="project-desc">
                A feature-rich task management app with drag-and-drop reordering, priority levels,
                and persistent local storage saving.
              </p>
              <div class="project-links">
                <a href="#" class="btn btn-sm btn-primary-custom" target="_blank">
                  <i class="bi bi-play-fill me-1"></i>Live Demo
                </a>
                <a href="#" class="btn btn-sm btn-ghost" target="_blank">
                  <i class="bi bi-github me-1"></i>GitHub
                </a>
              </div>
            </div>
          </div>
        </div>

        <!-- Project 3: Weather App -->
        <div class="col-md-6 col-lg-4 project-item fullstack" data-aos="fade-up" data-aos-delay="200">
          <div class="project-card">
            <div class="project-img-wrap">
              <img src="https://placehold.co/560x340/16213e/e8c547?text=Weather+App&font=playfair-display"
                   alt="Weather App" class="project-img" />
              <div class="project-overlay">
                <a href="#" class="overlay-btn" target="_blank">
                  <i class="bi bi-eye-fill"></i>
                </a>
                <a href="#" class="overlay-btn" target="_blank">
                  <i class="bi bi-github"></i>
                </a>
              </div>
            </div>
            <div class="project-body">
              <div class="project-tags">
                <span class="tag">JavaScript</span>
                <span class="tag">REST API</span>
                <span class="tag">Bootstrap</span>
              </div>
              <h5 class="project-title">Weather App</h5>
              <p class="project-desc">
                A real-time weather application that fetches live data from the OpenWeather API,
                displaying forecasts with beautiful animated icons.
              </p>
              <div class="project-links">
                <a href="#" class="btn btn-sm btn-primary-custom" target="_blank">
                  <i class="bi bi-play-fill me-1"></i>Live Demo
                </a>
                <a href="#" class="btn btn-sm btn-ghost" target="_blank">
                  <i class="bi bi-github me-1"></i>GitHub
                </a>
              </div>
            </div>
          </div>
        </div>

        <!-- Project 4: E-Commerce UI -->
        <div class="col-md-6 col-lg-4 project-item frontend" data-aos="fade-up" data-aos-delay="0">
          <div class="project-card">
            <div class="project-img-wrap">
              <img src="https://placehold.co/560x340/1a1a2e/e8c547?text=E-Commerce+UI&font=playfair-display"
                   alt="E-Commerce UI" class="project-img" />
              <div class="project-overlay">
                <a href="#" class="overlay-btn" target="_blank">
                  <i class="bi bi-eye-fill"></i>
                </a>
                <a href="#" class="overlay-btn" target="_blank">
                  <i class="bi bi-github"></i>
                </a>
              </div>
            </div>
            <div class="project-body">
              <div class="project-tags">
                <span class="tag">HTML</span>
                <span class="tag">CSS</span>
                <span class="tag">Bootstrap</span>
              </div>
              <h5 class="project-title">E-Commerce UI</h5>
              <p class="project-desc">
                A sleek product listing and checkout UI template with cart functionality,
                product filters, and a clean modern aesthetic.
              </p>
              <div class="project-links">
                <a href="#" class="btn btn-sm btn-primary-custom" target="_blank">
                  <i class="bi bi-play-fill me-1"></i>Live Demo
                </a>
                <a href="#" class="btn btn-sm btn-ghost" target="_blank">
                  <i class="bi bi-github me-1"></i>GitHub
                </a>
              </div>
            </div>
          </div>
        </div>

        <!-- Project 5: Blog Platform -->
        <div class="col-md-6 col-lg-4 project-item fullstack" data-aos="fade-up" data-aos-delay="100">
          <div class="project-card featured">
            <div class="featured-tag">⭐ Featured</div>
            <div class="project-img-wrap">
              <img src="https://placehold.co/560x340/0f3460/e8c547?text=Blog+Platform&font=playfair-display"
                   alt="Blog Platform" class="project-img" />
              <div class="project-overlay">
                <a href="#" class="overlay-btn" target="_blank">
                  <i class="bi bi-eye-fill"></i>
                </a>
                <a href="#" class="overlay-btn" target="_blank">
                  <i class="bi bi-github"></i>
                </a>
              </div>
            </div>
            <div class="project-body">
              <div class="project-tags">
                <span class="tag">JavaScript</span>
                <span class="tag">Node.js</span>
                <span class="tag">REST API</span>
              </div>
              <h5 class="project-title">Blog Platform</h5>
              <p class="project-desc">
                A full-featured blogging platform with Markdown support, tagging system,
                user authentication, and an admin dashboard.
              </p>
              <div class="project-links">
                <a href="#" class="btn btn-sm btn-primary-custom" target="_blank">
                  <i class="bi bi-play-fill me-1"></i>Live Demo
                </a>
                <a href="#" class="btn btn-sm btn-ghost" target="_blank">
                  <i class="bi bi-github me-1"></i>GitHub
                </a>
              </div>
            </div>
          </div>
        </div>

        <!-- Project 6: Quiz App -->
        <div class="col-md-6 col-lg-4 project-item frontend" data-aos="fade-up" data-aos-delay="200">
          <div class="project-card">
            <div class="project-img-wrap">
              <img src="https://placehold.co/560x340/16213e/e8c547?text=Quiz+App&font=playfair-display"
                   alt="Quiz App" class="project-img" />
              <div class="project-overlay">
                <a href="#" class="overlay-btn" target="_blank">
                  <i class="bi bi-eye-fill"></i>
                </a>
                <a href="#" class="overlay-btn" target="_blank">
                  <i class="bi bi-github"></i>
                </a>
              </div>
            </div>
            <div class="project-body">
              <div class="project-tags">
                <span class="tag">JavaScript</span>
                <span class="tag">Open Trivia API</span>
              </div>
              <h5 class="project-title">Quiz App</h5>
              <p class="project-desc">
                An interactive quiz application powered by the Open Trivia API with score tracking,
                timers, difficulty selection, and category filters.
              </p>
              <div class="project-links">
                <a href="#" class="btn btn-sm btn-primary-custom" target="_blank">
                  <i class="bi bi-play-fill me-1"></i>Live Demo
                </a>
                <a href="#" class="btn btn-sm btn-ghost" target="_blank">
                  <i class="bi bi-github me-1"></i>GitHub
                </a>
              </div>
            </div>
          </div>
        </div>

      </div><!-- /row -->
    </div>
  </section>


  <!-- ============================================================
       RESUME SECTION
  ============================================================ -->
  <section id="resume" class="section-pad resume-section d-none">
    <div class="container">

      <div class="section-header text-center mb-5">
        <p class="section-label">My Journey</p>
        <h2 class="section-title">Resume &amp; <span class="highlight">Experience</span></h2>
      </div>

      <div class="row g-5">

        <!-- Experience Column -->
        <div class="col-lg-6" data-aos="fade-right">
          <h4 class="timeline-heading">
            <i class="bi bi-briefcase-fill me-2"></i>Experience
          </h4>
          <div class="timeline">
            <div class="timeline-item">
              <div class="tl-dot"></div>
              <div class="tl-content">
                <span class="tl-date">2023 – Present</span>
                <h5>Junior Web Developer</h5>
                <p class="tl-company"><i class="bi bi-building me-1"></i>Tech Company Inc.</p>
                <p>Developed and maintained responsive web applications using HTML, CSS, JavaScript, and Bootstrap. Collaborated with design and backend teams to ship high-quality features.</p>
              </div>
            </div>
            <div class="timeline-item">
              <div class="tl-dot"></div>
              <div class="tl-content">
                <span class="tl-date">2022 – 2023</span>
                <h5>Frontend Intern</h5>
                <p class="tl-company"><i class="bi bi-building me-1"></i>Creative Studio LLC</p>
                <p>Assisted in designing and implementing UI components. Gained hands-on experience with version control and agile development workflows.</p>
              </div>
            </div>
            <div class="timeline-item">
              <div class="tl-dot"></div>
              <div class="tl-content">
                <span class="tl-date">2021</span>
                <h5>Freelance Developer</h5>
                <p class="tl-company"><i class="bi bi-person-workspace me-1"></i>Self-Employed</p>
                <p>Delivered custom websites for small businesses and entrepreneurs, focusing on clean design and performance optimization.</p>
              </div>
            </div>
          </div>
        </div>

        <!-- Education Column -->
        <div class="col-lg-6" data-aos="fade-left">
          <h4 class="timeline-heading">
            <i class="bi bi-mortarboard-fill me-2"></i>Education
          </h4>
          <div class="timeline">
            <div class="timeline-item">
              <div class="tl-dot"></div>
              <div class="tl-content">
                <span class="tl-date">2019 – 2023</span>
                <h5>B.Sc. Computer Science</h5>
                <p class="tl-company"><i class="bi bi-building me-1"></i>Your University</p>
                <p>Graduated with honours. Specialized in web technologies, algorithms, and software engineering. Served as president of the coding club.</p>
              </div>
            </div>
            <div class="timeline-item">
              <div class="tl-dot"></div>
              <div class="tl-content">
                <span class="tl-date">2022</span>
                <h5>Full-Stack Web Development</h5>
                <p class="tl-company"><i class="bi bi-laptop me-1"></i>Online Bootcamp</p>
                <p>Intensive 6-month bootcamp covering JavaScript, Node.js, databases, and deployment. Built 5 production-ready projects.</p>
              </div>
            </div>
            <div class="timeline-item">
              <div class="tl-dot"></div>
              <div class="tl-content">
                <span class="tl-date">2021</span>
                <h5>Responsive Web Design Certification</h5>
                <p class="tl-company"><i class="bi bi-award me-1"></i>freeCodeCamp</p>
                <p>Completed 300+ hours of coursework covering HTML, CSS, Flexbox, Grid, and accessibility best practices.</p>
              </div>
            </div>
          </div>
        </div>

      </div>

      <!-- Download CTA -->
      <div class="text-center mt-5 d-none" data-aos="fade-up">
        <div class="resume-cta-box">
          <p>Want the full picture? Download my complete resume.</p>
          <!-- Replace href with your actual PDF path -->
          <a href="resume.pdf" class="btn btn-primary-custom btn-lg" download>
            <i class="bi bi-cloud-arrow-down-fill me-2"></i>Download Resume (PDF)
          </a>
        </div>
      </div>

    </div>
  </section>


  <!-- ============================================================
       CONTACT SECTION
  ============================================================ -->
  <section id="contact" class="section-pad contact-section">
    <div class="container">

      <div class="section-header text-center mb-5">
        <p class="section-label">Get In Touch</p>
        <h2 class="section-title">Contact <span class="highlight">Me</span></h2>
      </div>

      <div class="row g-5 align-items-start">

        <!-- Contact Info -->
        <div class="col-lg-5" data-aos="fade-right">
          <h3 class="contact-heading">Let's work together.</h3>
          <p class="contact-sub">
            Have a project in mind, a question, or just want to say hi?
            I'd love to hear from you. Fill out the form or reach me through any of the channels below.
          </p>

          <div class="contact-info-list">
            <a href="mailto:krishna66dev@gmail.com" class="contact-info-item">
              <div class="ci-icon"><i class="bi bi-envelope-fill"></i></div>
              <div>
                <span class="ci-label">Email</span>
                <span class="ci-val">krishna66dev@gmail.com</span>
              </div>
            </a>
            <a href="https://linkedin.com/in/yourname" target="_blank" class="contact-info-item">
              <div class="ci-icon ci-linkedin"><i class="bi bi-linkedin"></i></div>
              <div>
                <span class="ci-label">LinkedIn</span>
                <span class="ci-val">linkedin.com/in/yourname</span>
              </div>
            </a>
            <a href="https://github.com/yourname" target="_blank" class="contact-info-item">
              <div class="ci-icon ci-github"><i class="bi bi-github"></i></div>
              <div>
                <span class="ci-label">GitHub</span>
                <span class="ci-val">github.com/yourname</span>
              </div>
            </a>
          </div>

          <!-- Availability status -->
          <div class="availability-badge">
            <span class="avail-dot"></span>
            Currently available for freelance &amp;
          </div>
        </div>

        <!-- Contact Form -->
        <div class="col-lg-7" data-aos="fade-left">
          <div class="contact-form-card">
            <div id="formSuccess" class="form-success d-none">
              <i class="bi bi-check-circle-fill"></i>
              <h5>Message Sent!</h5>
              <p>Thanks for reaching out. I'll get back to you within 24 hours.</p>
            </div>

            <!-- NOTE: Use onsubmit handler; no <form> action needed for demo -->
            <form id="contactForm" >
              <div class="row g-3">
                <div class="col-sm-6">
                  <label for="fname" class="form-label">First Name</label>
                  <input type="text" id="fname" name="fname" class="form-control custom-input" placeholder="John" required />
                </div>
                <div class="col-sm-6">
                  <label for="lname" class="form-label">Last Name</label>
                  <input type="text" id="lname" name="lname" class="form-control custom-input" placeholder="Doe" required />
                </div>
                <div class="col-12">
                  <label for="email" class="form-label">Email Address</label>
                  <input type="email" id="email" name="email" class="form-control custom-input" placeholder="john@example.com" required />
                </div>
                <div class="col-12">
                  <label for="email" class="form-label">Mobile No.</label>
                  <input type="email" id="mobile" name="mobile" class="form-control custom-input" placeholder="john@example.com" required />
                </div>
                <div class="col-12">
                  <label for="subject" class="form-label">Subject</label>
                  <input type="text" id="subject" name="subject" class="form-control custom-input" placeholder="Project Inquiry" required />
                </div>
                <div class="col-12">
                  <label for="message" class="form-label">Message</label>
                  <textarea id="message" name="message" class="form-control custom-input" rows="5"
                            placeholder="Tell me about your project..." required></textarea>
                </div>
                <div class="col-12">
                  <button type="button" class="btn btn-primary-custom w-100" onclick="handleFormSubmit()">
                    <i class="bi bi-send-fill me-2"></i>Send Message
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>

      </div>
    </div>
  </section>


  <!-- ============================================================
       FOOTER
  ============================================================ -->
  <footer class="site-footer">
    <div class="container">
      <div class="footer-inner">

        <!-- Brand -->
        <div class="footer-brand">
          <a class="navbar-brand" href="#home">
            <span class="brand-dot"></span>KP<span class="brand-period">.</span>
          </a>
          <p>Building the web, one line at a time.</p>
          <div class="footer-social-col">
          <h6>Follow Me</h6>
          <div class="social-icons">
            <a href="https://github.com/yourname" target="_blank" class="social-icon" aria-label="GitHub">
              <i class="bi bi-github"></i>
            </a>
            <a href="https://linkedin.com/in/yourname" target="_blank" class="social-icon" aria-label="LinkedIn">
              <i class="bi bi-linkedin"></i>
            </a>
            <a href="https://twitter.com/yourname" target="_blank" class="social-icon" aria-label="Twitter">
              <i class="bi bi-twitter-x"></i>
            </a>
            <a href="https://codepen.io/yourname" target="_blank" class="social-icon" aria-label="CodePen">
              <i class="bi bi-code-slash"></i>
            </a>
          </div>
        </div>
        </div>

        <!-- Quick Links -->
        <div class="footer-links">
          <h6>Quick Links</h6>
          <ul>
            <li><a href="#home">Home</a></li>
            <li><a href="#about">About</a></li>
            <!-- <li><a href="#projects">Projects</a></li> -->
            <li><a href="#contact">Contact</a></li>
          </ul>
        </div>
        
        <div class="footer-links">
          <h6>Tools</h6>
          <ul>
            <li><a href="https://kp-portfolio.42web.io/webp-image-converter.php">Webp Image Converter</a></li>
            <li><a href="https://kp-portfolio.42web.io/jpgconverter/">WEBP JPG PNG Converter</a></li>
            <li><a href="https://kp-portfolio.42web.io/AgeCalcualtor">Age Calcualtor</a></li>
            
          </ul>
        </div>

        
        

      </div>

      <!-- Footer Bottom -->
      <div class="footer-bottom">
        <p>&copy; <span id="year"></span> Krishna. Crafted with <i class="bi bi-heart-fill"></i> and lots of ☕</p>
        <p>
          <a href="#">Privacy Policy</a> &nbsp;·&nbsp; <a href="#">Terms of Use</a>
        </p>
      </div>
    </div>
  </footer>

  <!-- Back to Top Button -->
  <button id="backToTop" class="back-to-top" aria-label="Back to top">
    <i class="bi bi-arrow-up"></i>
  </button>


  <!-- ============================================================
       SCRIPTS
  ============================================================ -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"  referrerpolicy="no-referrer"></script>
  <script src="script.js"></script>

  <script>
    function handleFormSubmit() {

        var formData = $("#contactForm").serialize();
        let name  = $("#fname").val();
        let lname  = $("#lname").val();
        let email = $("#email").val();
        let mobile = $("#mobile").val();
        let subject = $("#subject").val();
        let message = $("#message").val();

        let emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if(name === "" || email === "" || mobile === "" || subject === "" || message === "" || lname === "") {
            alert("Please fill in all the required fields.");
            return;
        }

        if(!emailRegex.test(email)) {
            alert("Please enter a valid email address.");
            return;
        }

        if(mobile.length !== 10) {
            alert("Please enter a valid 10-digit mobile number.");
            return;
        }


        $.ajax({
            url: "contact-form.php",  
            type: "POST",
            data: formData,
            success: function(response) {
                if(response === "success") {
                    // alert("Message sent successfully!");
                    $('#formSuccess').removeClass('d-none');
                    $('html, body').animate({
                          scrollTop: $('#formSuccess').offset().top - 100
                      }, 500);
                    $("#contactForm")[0].reset();
                } else {
                    alert("Error sending message. Please try again.");
                }
            },
            error: function(xhr, status, error) {
                console.log(error);
                alert("Something went wrong!");
            }
        });

    }
  </script>
</body>
</html>