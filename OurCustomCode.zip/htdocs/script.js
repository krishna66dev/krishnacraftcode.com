/* ============================================================
   SCRIPT.JS — Personal Portfolio
   Features:
   · Sticky navbar with scroll effect
   · Active nav link highlighting
   · Smooth scroll (CSS-driven + JS fallback)
   · Skill bar animation on scroll
   · AOS-like scroll reveal animations
   · Project filter (client-side)
   · Contact form pseudo-submission
   · Back-to-top button
   · Auto-update footer year
============================================================ */

'use strict';

// ─── DOM References ───────────────────────────────────────────
const mainNav     = document.getElementById('mainNav');
const backToTop   = document.getElementById('backToTop');
const yearSpan    = document.getElementById('year');
const navLinks    = document.querySelectorAll('.nav-link[href^="#"]');
const sections    = document.querySelectorAll('section[id]');
const filterBtns  = document.querySelectorAll('.filter-btn');
const projectItems= document.querySelectorAll('.project-item');
const skillFills  = document.querySelectorAll('.skill-bar-fill');
const aosEls      = document.querySelectorAll('[data-aos]');


// ─── 1. Footer Year ───────────────────────────────────────────
if (yearSpan) yearSpan.textContent = new Date().getFullYear();


// ─── 2. Navbar Scroll Effect ──────────────────────────────────
function handleNavScroll() {
  if (window.scrollY > 60) {
    mainNav.classList.add('scrolled');
  } else {
    mainNav.classList.remove('scrolled');
  }
}
window.addEventListener('scroll', handleNavScroll, { passive: true });
handleNavScroll(); // run once on load


// ─── 3. Back-to-Top Button ────────────────────────────────────
function handleBackToTop() {
  if (window.scrollY > 400) {
    backToTop.classList.add('visible');
  } else {
    backToTop.classList.remove('visible');
  }
}
window.addEventListener('scroll', handleBackToTop, { passive: true });
backToTop.addEventListener('click', () => {
  window.scrollTo({ top: 0, behavior: 'smooth' });
});


// ─── 4. Active Nav Link on Scroll ─────────────────────────────
function setActiveNavLink() {
  let currentId = '';
  sections.forEach(section => {
    const top    = section.offsetTop - 100;
    const height = section.offsetHeight;
    if (window.scrollY >= top && window.scrollY < top + height) {
      currentId = section.id;
    }
  });

  navLinks.forEach(link => {
    link.classList.remove('active');
    if (link.getAttribute('href') === `#${currentId}`) {
      link.classList.add('active');
    }
  });
}
window.addEventListener('scroll', setActiveNavLink, { passive: true });
setActiveNavLink();


// ─── 5. Close mobile menu on link click ───────────────────────
navLinks.forEach(link => {
  link.addEventListener('click', () => {
    const bsCollapse = document.getElementById('navbarNav');
    if (bsCollapse && bsCollapse.classList.contains('show')) {
      const toggler = document.querySelector('.navbar-toggler');
      if (toggler) toggler.click();
    }
  });
});


// ─── 6. Scroll Reveal (AOS-like) ──────────────────────────────
const aosObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        // Respect optional delay attribute
        const delay = entry.target.dataset.aosDelay || 0;
        setTimeout(() => {
          entry.target.classList.add('aos-animate');
        }, parseInt(delay));
        aosObserver.unobserve(entry.target);
      }
    });
  },
  { threshold: 0.12, rootMargin: '0px 0px -40px 0px' }
);

aosEls.forEach(el => aosObserver.observe(el));


// ─── 7. Skill Bar Animation ───────────────────────────────────
const skillObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const bar = entry.target;
        const pct = bar.dataset.pct || '0';
        // Small delay for visual polish
        setTimeout(() => {
          bar.style.width = pct + '%';
        }, 200);
        skillObserver.unobserve(bar);
      }
    });
  },
  { threshold: 0.4 }
);

skillFills.forEach(fill => skillObserver.observe(fill));


// ─── 8. Project Filter ────────────────────────────────────────
filterBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    // Update active state
    filterBtns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');

    const filter = btn.dataset.filter;

    projectItems.forEach(item => {
      const show = filter === 'all' || item.classList.contains(filter);

      if (show) {
        item.style.display = '';
        // Slight fade-in effect
        item.style.opacity = '0';
        item.style.transform = 'translateY(20px)';
        requestAnimationFrame(() => {
          requestAnimationFrame(() => {
            item.style.transition = 'opacity 0.4s ease, transform 0.4s ease';
            item.style.opacity = '1';
            item.style.transform = 'translateY(0)';
          });
        });
      } else {
        item.style.transition = 'opacity 0.25s ease';
        item.style.opacity = '0';
        setTimeout(() => {
          item.style.display = 'none';
        }, 250);
      }
    });
  });
});


// ─── 9. Contact Form (Demo Submit) ────────────────────────────
/**
 * handleFormSubmit()
 * Called by the Send button's onclick attribute.
 * Validates inputs and shows a success message.
 * In production, replace the setTimeout block with a real
 * fetch() call to your backend or a service like Formspree/EmailJS.
 */
function handleFormSubmit() {
  const fname   = document.getElementById('fname');
  const lname   = document.getElementById('lname');
  const email   = document.getElementById('email');
  const subject = document.getElementById('subject');
  const message = document.getElementById('message');
  const fields  = [fname, lname, email, subject, message];

  // ── Basic Validation ──
  let valid = true;
  fields.forEach(field => {
    field.style.borderColor = '';
    if (!field.value.trim()) {
      field.style.borderColor = '#e74c3c';
      valid = false;
    }
  });

  // Email format check
  if (email && email.value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value)) {
    email.style.borderColor = '#e74c3c';
    valid = false;
  }

  if (!valid) {
    shakeButton();
    return;
  }

  // ── Simulate Submission ──
  const btn = document.querySelector('#contactForm .btn-primary-custom');
  if (btn) {
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span> Sending…';
  }

  // In production: replace this setTimeout with a fetch() call
  setTimeout(() => {
    const form    = document.getElementById('contactForm');
    const success = document.getElementById('formSuccess');
    if (form)    form.classList.add('d-none');
    if (success) success.classList.remove('d-none');
  }, 1500);
}

/** Briefly shakes the submit button to signal validation error */
function shakeButton() {
  const btn = document.querySelector('#contactForm .btn-primary-custom');
  if (!btn) return;
  btn.style.animation = 'shake 0.4s ease';
  btn.addEventListener('animationend', () => {
    btn.style.animation = '';
  }, { once: true });
}

// Inject shake keyframes dynamically
(function injectShakeKeyframes() {
  const style = document.createElement('style');
  style.textContent = `
    @keyframes shake {
      0%,100% { transform: translateX(0); }
      20%      { transform: translateX(-6px); }
      40%      { transform: translateX(6px); }
      60%      { transform: translateX(-4px); }
      80%      { transform: translateX(4px); }
    }
  `;
  document.head.appendChild(style);
})();


// ─── 10. Typed-title Effect (Hero) ────────────────────────────
/**
 * Cycles through job titles in the hero section.
 * Targets the <h2 class="hero-title"> element.
 */
(function typedTitle() {
  const titles = ['Web Developer', 'UI Designer', 'Frontend Engineer', 'Problem Solver'];
  const el = document.querySelector('.hero-title');
  if (!el) return;

  let titleIndex = 0;
  let charIndex  = 0;
  let isDeleting = false;

  // Preserve the cursor element
  const cursor = el.querySelector('.cursor-blink');

  function getTextNode() {
    // Text content before the cursor span
    return el.childNodes[0];
  }

  function type() {
    const current = titles[titleIndex];
    const textNode = getTextNode();
    if (!textNode) return;

    if (isDeleting) {
      textNode.textContent = current.slice(0, charIndex - 1);
      charIndex--;
    } else {
      textNode.textContent = current.slice(0, charIndex + 1);
      charIndex++;
    }

    let delay = isDeleting ? 60 : 100;

    if (!isDeleting && charIndex === current.length) {
      // Pause at end
      delay = 2000;
      isDeleting = true;
    } else if (isDeleting && charIndex === 0) {
      isDeleting = false;
      titleIndex = (titleIndex + 1) % titles.length;
      delay = 400;
    }

    setTimeout(type, delay);
  }

  // Kick off after a short delay
  setTimeout(type, 1200);
})();


// ─── 11. Smooth Scroll Fallback (for older browsers) ──────────
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    const targetId = this.getAttribute('href');
    if (targetId === '#') return;
    const target = document.querySelector(targetId);
    if (!target) return;
    e.preventDefault();
    const offset = mainNav ? mainNav.offsetHeight + 8 : 80;
    const top = target.getBoundingClientRect().top + window.pageYOffset - offset;
    window.scrollTo({ top, behavior: 'smooth' });
  });
});


// ─── 12. Navbar collapse on resize (prevent stuck open state) ─
window.addEventListener('resize', () => {
  if (window.innerWidth >= 992) {
    const bsCollapse = document.getElementById('navbarNav');
    if (bsCollapse && bsCollapse.classList.contains('show')) {
      const toggler = document.querySelector('.navbar-toggler');
      if (toggler) toggler.click();
    }
  }
});