<?php 

$base_url = "http://localhost/admin/";

session_start();
?>