<?php include 'config.php'; ?>

<!DOCTYPE html>
<html lang="en">

<head>
	<?php include 'include/head.php'; ?>
</head>

<body>
	<div class="wrapper">
		<?php include 'include/sidebar.php'; ?>

		<div class="main">
			<?php include 'include/header.php'; ?>

			<main class="content">
				<div class="container-fluid p-0">

					<h1 class="h3 mb-3">Blank Page</h1>

					<div class="row">
						<div class="col-12">
							<div class="card">
								<div class="card-header">
									<h5 class="card-title mb-0">Empty card</h5>
								</div>
								<div class="card-body">
								</div>
							</div>
						</div>
					</div>

				</div>
			</main>

			<?php include 'include/footer.php'; ?>
		</div>
	</div>

	

</body>

</html>