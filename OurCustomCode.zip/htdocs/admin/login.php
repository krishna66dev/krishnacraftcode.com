<?php

require_once "config.php";

if(isset($_SESSION['UserId'])) {
	header("Location: index.php");
}
$msg='';
if (isset($_POST['login'])) {
	require_once "Database.php";
	$db = new Database();
	$conn = $db->getConnection();

	$email = $_POST['email'];
	$password = $_POST['password'];

	$sql = "SELECT * FROM users WHERE UserEmail = '$email' AND Pasword = '$password'";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		$row = $result->fetch_assoc();
	
		$_SESSION['UserId'] = $row['Id'];
		$_SESSION['UserEmail'] = $row['UserEmail'];
		$_SESSION['UserName'] = $row['Name'];
		$_SESSION['UserType'] = $row['Type'];
		header("Location: index.php");
	} else {
		$msg = "Invalid email or password";
	}
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
	<?php include 'include/head.php'; ?>
</head>

<body>
	<main class="d-flex w-100">
		<div class="container d-flex flex-column">
			<div class="row vh-100">
				<div class="col-sm-10 col-md-8 col-lg-6 col-xl-5 mx-auto d-table h-100">
					<div class="d-table-cell align-middle">

						<div class="text-center mt-4">
							<h1 class="h2">Welcome back!</h1>
							<p class="lead">
								Sign in to your account to continue
							</p>
						</div>

						<div class="card">
							<div class="card-body">
								<div class="m-sm-3">
									<form id="Loginform" method="POST" >
										<div class="mb-3">
											<label class="form-label">Email</label>
											<input class="form-control form-control-lg" type="email" name="email"
												placeholder="Enter your email" />
										</div>
										<div class="mb-3">
											<label class="form-label">Password</label>
											<input class="form-control form-control-lg" type="password" name="password"
												placeholder="Enter your password" />
										</div>
										<div>
											<!-- <div class="form-check align-items-center">
												<input id="customControlInline" type="checkbox" class="form-check-input" value="remember-me" name="remember-me" >
												<label class="form-check-label text-small" for="customControlInline">Remember me</label>
											</div> -->
										</div>
										<div class="d-grid gap-2 mt-3">
											<button name="login" id="login" class="btn btn-lg btn-primary">Sign
												in</button>
										</div>
										<div class="mt-2 text-danger" >
											<?=$msg?>
										</div>
									</form>
								</div>
							</div>
						</div>
						<!-- <div class="text-center mb-3">
							Don't have an account? <a href="pages-sign-up.php">Sign up</a>
						</div> -->
					</div>
				</div>
			</div>
		</div>
	</main>

	<script src="static/js/app.js"></script>

</body>

</html>