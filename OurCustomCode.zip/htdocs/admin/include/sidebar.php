<nav id="sidebar" class="sidebar js-sidebar">
	<div class="sidebar-content js-simplebar">
		<a class="sidebar-brand" href="index.php">
			<span class="align-middle">AdminKit</span>
		</a>

		<ul class="sidebar-nav">
			<li class="sidebar-header">
				Pages
			</li>

			<li class="sidebar-item active">
				<a class="sidebar-link" href="index.php">
					<i class="align-middle" data-feather="sliders"></i> <span class="align-middle">Dashboard</span>
				</a>
			</li>

			<li class="sidebar-item">
				<a class="sidebar-link" href="pages-profile.php">
					<i class="align-middle" data-feather="user"></i> <span class="align-middle">Profile</span>
				</a>
			</li>

			<!-- <li class="sidebar-item">
						<a class="sidebar-link" href="pages-sign-in.php">
			  <i class="align-middle" data-feather="log-in"></i> <span class="align-middle">Sign In</span>
			</a>
					</li> -->



			<li class="sidebar-item">
				<a class="sidebar-link" href="contact-us-list.php">
					<i class="align-middle" data-feather="book"></i> <span class="align-middle">Contact Us</span>
				</a>
			</li>
			<li class="sidebar-item">
				<a class="sidebar-link" href="pages-blank.php">
					<i class="align-middle" data-feather="book"></i> <span class="align-middle">Blank</span>
				</a>
			</li>


			<li class="sidebar-item">
				<a class="sidebar-link" href="logout.php">
					<i class="align-middle" data-feather="log-out"></i> <span class="align-middle">Log Out</span>
				</a>
			</li>

		</ul>


	</div>
</nav>