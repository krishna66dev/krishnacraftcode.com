<?php
    include 'config.php'; 
    require_once "Database.php";
	$db = new Database();
	$conn = $db->getConnection();
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<?php include 'include/head.php'; ?>
    
    <style>
        .message{
        display: -webkit-box;
        -webkit-line-clamp: 2;   
        -webkit-box-orient: vertical;
        overflow: hidden;
        text-overflow: ellipsis;
        }
        .table td, .table th {
            padding: 3px 6px;
        }
    </style>	
   
</head>

<body>
	<div class="wrapper">
		<?php include 'include/sidebar.php'; ?>

		<div class="main">
			<?php include 'include/header.php'; ?>

			<main class="content">
				<div class="container-fluid p-0">

					<h1 class="h3 mb-3">Contact Us</h1>

					<div class="row">
						<div class="col-12">
							<div class="card">
								<div class="card-header">
									<h5 class="card-title mb-0">Contact Us List</h5>
								</div>
								<div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered">
                                            <thead class="table-active">
                                                <tr>
                                                <th scope="col">#</th>
                                                <th class="text-nowrap" scope="col">First Name</th>
                                                <th class="text-nowrap" scope="col">Last Name</th>
                                                <th class="text-nowrap" scope="col">Email</th>
                                                <th class="text-nowrap" scope="col">Mobile</th>
                                                <th class="text-nowrap" scope="col">Subject</th>
                                                <th class="text-nowrap" scope="col">Message</th>
                                                <th class="text-nowrap" scope="col">Date Time</th>
                                                <th class="text-nowrap" scope="col">IP Address</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php 

                                                    $sql = "SELECT * FROM Contact_us";
                                                    $result = $conn->query($sql);
                                                    $i=1;
                                                    while($row = $result->fetch_assoc()) {
                                                        $date = date("d-m-Y h:i", strtotime($row["CreatedAt"]));

                                                        ?>

                                                        <tr>
                                                            <td><?=$i++ ?></td>
                                                            <td><?=$row['firstName']?></td>
                                                            <td><?=$row['lastName']?></td>
                                                            <td><?=$row['Email']?></td>
                                                            <td><?=$row['Mobile']?></td>
                                                            <td><?=$row['Subject']?></td>
                                                            <td><div title="<?=$row['Message']?>" class="message"><?=$row['Message']?></div></td>
                                                            <td class="text-nowrap" ><?=$date?></td>
                                                            <td><?=$row['IPAddress']?></td>
                                                        </tr>
                                                        <?php
                                                    }

                                                  ?>
                                               
                                            </tbody>
                                            </table>
                                    </div>
								</div>
							</div>
						</div>
					</div>

				</div>
			</main>

			<?php include 'include/footer.php'; ?>
		</div>
	</div>

	

</body>

</html>