<?php  

class Database {

    private $host = "sql201.infinityfree.com";
    private $username = "if0_41354433";
    private $password = "sHEY2omMi16nN";
    private $database = "if0_41354433_portfolio_db";

    public $conn;

    public function __construct() {

        $this->conn = new mysqli(
            $this->host,
            $this->username,
            $this->password,
            $this->database
        );

        // Check connection
        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        }
    }

    public function getConnection() {
        return $this->conn;
    }
}
?>